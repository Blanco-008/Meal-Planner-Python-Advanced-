# ============================================================
# SMART MEAL PLANNER - SIMPLE EXPLAINED VERSION
# ============================================================
# This file is a beginner-friendly copy of the app.
# The comments are written in a very simple way so a beginner can understand.
# If you want the real project file, open main.py.
# This file is only for learning and easier reading.
# ============================================================

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import threading

from mealdb_client import MealDBClient, MealNotFoundError, APIRequestError
from recipe import Recipe
from planner import MealPlanner, ShoppingListGenerator, save_json, load_json, GeminiHelper, validate_servings


class RecipePlannerApp:
    """
    This class creates the whole app window.
    It controls:
    - searching meals
    - showing recipe details
    - saving favourites
    - adding meals to the weekly plan
    - generating shopping list
    - asking Gemini AI for help
    """

    def __init__(self, root):
        # root = the main window of the app
        self.root = root
        self.root.title("Smart Meal Planner")
        self.root.geometry("800x700")

        # These objects do the actual work in the background.
        self.client = MealDBClient()
        self.planner = MealPlanner()
        self.shopping_list = []
        self.favourites = []
        self.current_recipe = None
        self.result_ids = []

        # Try to start Gemini AI.
        # If there is no API key, it will just stay off.
        try:
            self.gemini = GeminiHelper()
        except ValueError as e:
            self.gemini = None
            self.gemini_error = str(e)

        # Build the GUI and load saved files after the window is ready.
        self.create_widgets()
        self.load_all_data()

    # ========================================================
    # 1) BUILDING THE USER INTERFACE
    # ========================================================
    def create_widgets(self):
        """Create all buttons, boxes, labels, and text areas."""

        # -------------------- Search section --------------------
        search_frame = ttk.LabelFrame(self.root, text="Search Recipes", padding=10)
        search_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(search_frame, text="Search by:").grid(row=0, column=0, padx=5)
        self.search_type = tk.StringVar(value="name")
        search_combo = ttk.Combobox(
            search_frame,
            textvariable=self.search_type,
            state="readonly",
            values=["name", "ingredient", "category"]
        )
        search_combo.grid(row=0, column=1, padx=5)

        self.search_entry = ttk.Entry(search_frame, width=30)
        self.search_entry.grid(row=0, column=2, padx=5)

        self.search_button = ttk.Button(search_frame, text="Search", command=self.start_search)
        self.search_button.grid(row=0, column=3, padx=5)

        # -------------------- Results list --------------------
        results_frame = ttk.LabelFrame(self.root, text="Results", padding=10)
        results_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.results_list = tk.Listbox(results_frame, height=10)
        self.results_list.pack(fill="both", expand=True)
        self.results_list.bind("<<ListboxSelect>>", self.on_result_select)

        # -------------------- Recipe details area --------------------
        recipe_frame = ttk.LabelFrame(self.root, text="Recipe Details", padding=10)
        recipe_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.recipe_text = scrolledtext.ScrolledText(recipe_frame, wrap=tk.WORD, height=15)
        self.recipe_text.pack(fill="both", expand=True)

        # -------------------- AI and favourite buttons --------------------
        action_frame = ttk.Frame(self.root)
        action_frame.pack(fill="x", padx=10, pady=5)

        ttk.Button(action_frame, text="AI Assistant", command=self.start_gemini).pack(side=tk.LEFT, padx=5)
        ttk.Button(action_frame, text="Add to Favourites", command=self.add_favourite).pack(side=tk.LEFT, padx=5)

        # -------------------- Meal plan section --------------------
        plan_frame = ttk.LabelFrame(self.root, text="Add to Meal Plan", padding=10)
        plan_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(plan_frame, text="Day:").grid(row=0, column=0)
        self.day_var = tk.StringVar(value="Monday")
        day_combo = ttk.Combobox(
            plan_frame,
            textvariable=self.day_var,
            state="readonly",
            values=MealPlanner.VALID_DAYS
        )
        day_combo.grid(row=0, column=1, padx=5)

        ttk.Label(plan_frame, text="Servings:").grid(row=0, column=2)
        self.servings_entry = ttk.Entry(plan_frame, width=5)
        self.servings_entry.insert(0, "4")
        self.servings_entry.grid(row=0, column=3, padx=5)

        ttk.Button(plan_frame, text="Add to Plan", command=self.add_to_plan).grid(row=0, column=4, padx=5)

        # -------------------- Bottom buttons --------------------
        bottom_frame = ttk.Frame(self.root)
        bottom_frame.pack(fill="x", padx=10, pady=10)

        ttk.Button(bottom_frame, text="Show Meal Plan", command=self.show_meal_plan).pack(side=tk.LEFT, padx=5)
        ttk.Button(bottom_frame, text="Generate Shopping List", command=self.generate_shopping_list).pack(side=tk.LEFT, padx=5)
        ttk.Button(bottom_frame, text="Save All", command=self.save_all_data).pack(side=tk.LEFT, padx=5)
        ttk.Button(bottom_frame, text="Load Saved", command=self.load_all_data).pack(side=tk.LEFT, padx=5)

        # -------------------- Status bar --------------------
        # This tells the user what is happening.
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(fill="x", padx=10, pady=5)

    # ========================================================
    # 2) BACKGROUND WORKER
    # ========================================================
    def run_in_background(self, target, *args, callback=None):
        """
        Runs slow work in a background thread so the app does not freeze.
        When work finishes, it sends the result back to the main window.
        """

        def wrapper():
            try:
                result = target(*args)
                if callback:
                    self.root.after(0, callback, result)
            except Exception as e:
                if callback:
                    self.root.after(0, callback, e)
                else:
                    self.root.after(0, self.show_error, str(e))

        threading.Thread(target=wrapper, daemon=True).start()

    # ========================================================
    # 3) SEARCHING RECIPES
    # ========================================================
    def start_search(self):
        """Run a search when the user clicks Search."""
        query = self.search_entry.get().strip()
        if not query:
            messagebox.showwarning("Missing Input", "Please enter a search term.")
            return

        search_type = self.search_type.get()

        if search_type == "name":
            func = self.client.search_by_name
        elif search_type == "ingredient":
            func = self.client.search_by_ingredient
        else:
            func = self.client.search_by_category

        self.status_var.set("Searching...")
        self.search_button.config(state=tk.DISABLED)
        self.run_in_background(func, query, callback=self.search_complete)

    def search_complete(self, result):
        """This runs after the search is done."""
        self.search_button.config(state=tk.NORMAL)

        if isinstance(result, Exception):
            self.status_var.set("Search failed")
            messagebox.showerror("Search Error", str(result))
            return

        self.results_list.delete(0, tk.END)
        self.result_ids = []

        for meal in result:
            self.results_list.insert(tk.END, f"{meal['name']} (ID: {meal['id']})")
            self.result_ids.append(meal['id'])

        if result:
            self.status_var.set(f"Found {len(result)} results")
        else:
            self.status_var.set("No results")

    def on_result_select(self, event):
        """When the user clicks a recipe in the list, load that recipe."""
        selection = self.results_list.curselection()
        if not selection:
            return

        index = selection[0]
        meal_id = self.result_ids[index]
        self.status_var.set("Loading recipe...")
        self.run_in_background(self.client.get_recipe, meal_id, callback=self.recipe_loaded)

    def recipe_loaded(self, recipe):
        """Runs when a recipe is fully loaded from the API."""
        if isinstance(recipe, Exception):
            messagebox.showerror("Error", str(recipe))
            self.status_var.set("Failed to load recipe")
            return

        self.current_recipe = recipe
        self.display_recipe(recipe)
        self.status_var.set(f"Loaded {recipe.name}")

    def display_recipe(self, recipe):
        """Show ingredients and instructions in the text box."""
        self.recipe_text.delete(1.0, tk.END)

        text = f"{recipe.name}\n"
        text += f"Category: {recipe.category}\n"
        text += f"Cuisine: {recipe.cuisine}\n\n"
        text += "Ingredients:\n"
        for ing in recipe.ingredients:
            text += f"  - {ing['name']}: {ing['measure']}\n"
        text += "\nInstructions:\n"
        text += recipe.instructions

        self.recipe_text.insert(tk.END, text)

    # ========================================================
    # 4) AI ASSISTANT
    # ========================================================
    def start_gemini(self):
        """Ask Gemini AI for simpler instructions and changes."""
        if not self.current_recipe:
            messagebox.showwarning("No Recipe", "Please select a recipe first.")
            return

        if not self.gemini:
            messagebox.showerror("Gemini Unavailable", self.gemini_error)
            return

        self.status_var.set("Asking Gemini...")
        self.run_in_background(self.gemini.enhance_recipe, self.current_recipe, callback=self.gemini_done)

    def gemini_done(self, result):
        """This runs after Gemini replies."""
        if isinstance(result, Exception):
            self.status_var.set("Gemini failed")
            messagebox.showerror("Gemini Error", str(result))
            return

        self.status_var.set("Gemini response received")
        text = f"--- AI Enhanced ---\n\nDifficulty: {result['difficulty']}\n\n"
        text += f"Simplified Instructions:\n{result['simplified_instructions']}\n\n"
        text += "Substitutes:\n"
        for sub in result['substitutes']:
            text += f"  - {sub}\n"

        self.recipe_text.insert(tk.END, "\n\n" + text)

    # ========================================================
    # 5) MEAL PLANNING
    # ========================================================
    def add_to_plan(self):
        """Add the current recipe to the chosen day of the week."""
        if not self.current_recipe:
            messagebox.showwarning("No Recipe", "Please select a recipe first.")
            return

        day = self.day_var.get()
        servings_text = self.servings_entry.get()

        try:
            servings = validate_servings(servings_text)
        except ValueError as e:
            messagebox.showerror("Invalid Servings", str(e))
            return

        try:
            self.planner.add_meal(day, self.current_recipe, servings)
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return

        self.status_var.set(f"Added {self.current_recipe.name} to {day} for {servings} people")

    def show_meal_plan(self):
        """Open a window and show all planned meals."""
        plan_text = self.planner.get_all_meals()
        if not plan_text:
            messagebox.showinfo("Meal Plan", "No meals planned yet.")
            return

        win = tk.Toplevel(self.root)
        win.title("Meal Plan")
        text = scrolledtext.ScrolledText(win, wrap=tk.WORD, width=60, height=20)
        text.pack(fill="both", expand=True, padx=10, pady=10)

        for day, recipe, servings in plan_text:
            text.insert(tk.END, f"{day}: {recipe.name} ({servings} servings)\n")

    # ========================================================
    # 6) SHOPPING LIST
    # ========================================================
    def generate_shopping_list(self):
        """Create one big shopping list from all planned meals."""
        if not self.planner.get_all_meals():
            messagebox.showwarning("No Plan", "Add meals to the plan first.")
            return

        generator = ShoppingListGenerator(self.planner)
        shopping_list = generator.generate()
        self.shopping_list = shopping_list

        win = tk.Toplevel(self.root)
        win.title("Shopping List")
        text = scrolledtext.ScrolledText(win, wrap=tk.WORD, width=60, height=20)
        text.pack(fill="both", expand=True, padx=10, pady=10)

        for item in shopping_list:
            if item['quantity'] is not None:
                text.insert(tk.END, f"{item['name'].capitalize()}: {item['quantity']} {item['unit']}\n")
            else:
                text.insert(tk.END, f"{item['name'].capitalize()}: {item['original']} (unparsable)\n")

        self.status_var.set("Shopping list generated")

    # ========================================================
    # 7) FAVOURITES
    # ========================================================
    def add_favourite(self):
        """Save a recipe to favourites so it stays in the app."""
        if not self.current_recipe:
            messagebox.showwarning("No Recipe", "Select a recipe first.")
            return

        for fav in self.favourites:
            if fav['meal_id'] == self.current_recipe.meal_id:
                messagebox.showinfo("Already Favourite", "This recipe is already in favourites.")
                return

        self.favourites.append({
            "meal_id": self.current_recipe.meal_id,
            "name": self.current_recipe.name,
            "category": self.current_recipe.category,
            "cuisine": self.current_recipe.cuisine,
            "ingredients": self.current_recipe.ingredients,
            "instructions": self.current_recipe.instructions,
            "image_url": self.current_recipe.image_url
        })

        self.status_var.set(f"Added {self.current_recipe.name} to favourites")

    # ========================================================
    # 8) SAVE AND LOAD DATA
    # ========================================================
    def save_all_data(self):
        """Save the weekly plan, shopping list, and favourites to JSON files."""
        plan_data = {}
        for day, meals in self.planner.plan.items():
            plan_data[day] = []
            for entry in meals:
                recipe = entry['recipe']
                plan_data[day].append({
                    "recipe": {
                        "meal_id": recipe.meal_id,
                        "name": recipe.name,
                        "category": recipe.category,
                        "cuisine": recipe.cuisine,
                        "ingredients": recipe.ingredients,
                        "instructions": recipe.instructions,
                        "image_url": recipe.image_url
                    },
                    "servings": entry['servings']
                })

        try:
            save_json(plan_data, "meal_plan.json")
            save_json(self.shopping_list, "shopping_list.json")
            save_json(self.favourites, "favourites.json")
            self.status_var.set("All data saved")
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    def load_all_data(self):
        """Load saved JSON files when the app starts or when user presses Load Saved."""
        favs = load_json("favourites.json")
        if favs is not None:
            self.favourites = favs

        shop = load_json("shopping_list.json")
        if shop is not None:
            self.shopping_list = shop

        plan = load_json("meal_plan.json")
        if plan is not None:
            self.planner = MealPlanner()
            for day, meals in plan.items():
                for entry in meals:
                    recipe_data = entry["recipe"]
                    recipe = Recipe(
                        meal_id=recipe_data["meal_id"],
                        name=recipe_data["name"],
                        category=recipe_data["category"],
                        cuisine=recipe_data["cuisine"],
                        ingredients=recipe_data["ingredients"],
                        instructions=recipe_data["instructions"],
                        image_url=recipe_data["image_url"]
                    )
                    self.planner.add_meal(day, recipe, entry["servings"])

        self.status_var.set("Data loaded")

    # ========================================================
    # 9) FINAL ERROR HANDLER
    # ========================================================
    def show_error(self, message):
        """Show a popup error when something goes wrong."""
        messagebox.showerror("Error", message)


if __name__ == "__main__":
    # This only runs when you launch the file directly.
    root = tk.Tk()
    app = RecipePlannerApp(root)
    root.mainloop()
