# Smart Meal Planner Project Presentation and Work Sharing

## 1. Project Overview

The Smart Meal Planner is a Python desktop application that helps users search for meals, view recipe details, save favourite recipes, plan meals for the week, generate a shopping list, and use Gemini AI to simplify recipes and suggest ingredient substitutes.

The project combines multiple important areas of software development:

- Graphical User Interface (GUI)
- API integration
- Data modeling
- Meal planning logic
- AI integration
- File saving and loading

---

## 2. Team Work Sharing (5 People)

The work was divided into five key roles based on the project structure and responsibilities.

### Person 1: User Interface and Application Flow

Main file: `main.py`

Responsibilities:

- built the main Tkinter window,
- created search controls and recipe search area,
- designed the results list and recipe display panel,
- connected the buttons for favourites, AI assistance, and meal planning,
- handled status messages so the user knows what is happening,
- managed the app flow from search to result selection to recipe display.

### Person 2: External API and Data Retrieval

Main file: `mealdb_client.py`

Responsibilities:

- connected the app to TheMealDB,
- searched for meals by name,
- searched by ingredient,
- searched by category,
- requested a full recipe using the recipe ID,
- handled API errors such as no results or failed requests.

### Person 3: Recipe Model and Data Structure

Main file: `recipe.py`

Responsibilities:

- designed the `Recipe` class,
- converted raw API JSON into clean Python objects,
- stored recipe fields such as name, category, cuisine, ingredients, instructions, and image URL,
- made the recipe data easy for the rest of the app to use.

### Person 4: Meal Planning and Shopping List Logic

Main file: `planner.py`

Responsibilities:

- created the weekly meal planner,
- validated servings input,
- scheduled meals across each weekday,
- generated a combined shopping list from planned meals,
- saved and loaded meal plan data to JSON files,
- kept the plan logical and easy to use.

### Person 5: Gemini AI Integration

Main file: `planner.py`

Responsibilities:

- built the `GeminiHelper` class,
- sent recipe information to Gemini AI,
- requested simplified cooking instructions,
- generated a difficulty level,
- suggested ingredient substitutes,
- parsed the AI response and handled errors.

---

## 3. Realistic Team Summary for Presentation

The Smart Meal Planner was developed as a team project with equal focus on essential software components. One member handled the user interface and app flow, another connected the program to an online recipe database, one structured the recipe data model, another developed the meal planning and shopping features, and the final member integrated Gemini AI to improve the user experience.

This division of work reflects real-world software engineering, where different team members focus on different parts of the application and later combine them into one complete system. The result is a functional app that brings together front-end design, backend logic, external data, and AI assistance.

---

## 4. How to Present This Project

### Short presentation version

> Our project is a Smart Meal Planner app built in Python. It allows users to search for recipes, select meals, plan a weekly menu, generate a shopping list, and get AI-powered help for simpler instructions and ingredient substitutions. The system combines a graphical interface, API-based recipe retrieval, structured recipe objects, planning logic, and Gemini integration to create a useful and interactive tool.

### Medium presentation version

> The Smart Meal Planner is designed to simplify meal preparation and shopping. Users can search for recipes by name, ingredient, or category, view recipe details, add meals to their weekly plan, and generate a shopping list based on the selected meals. We also integrated Gemini AI to provide simplified cooking instructions and substitute suggestions. This project demonstrates practical software design and teamwork by combining UI development, data handling, planning logic, and AI-driven improvements.

### Academic/assignment-style version

> This project was implemented as a collaborative software development effort. The application provides the user with a complete meal-planning experience, including recipe search, recipe detail display, weekly planning, shopping list generation, and AI-enhanced recipe guidance. The system uses Python, Tkinter, external API integration, and the Google Gemini API. The project highlights the integration of front-end usability with data processing and intelligent assistance, making it both practical and technically engaging.

---

## 5. API Key Setup

The application uses a Gemini API key. The key should be stored as an environment variable, not embedded inside the code.

The app checks for either of these variable names:

- `GEMINI_API_KEY`
- `GOOGLE_API_KEY`

### Set it in the terminal for one session

```bash
export GEMINI_API_KEY="your_real_key_here"
python main.py
```

### Make it permanent for zsh

```bash
echo 'export GEMINI_API_KEY="your_real_key_here"' >> ~/.zshrc
source ~/.zshrc
```

### Alternative env name

```bash
export GOOGLE_API_KEY="your_real_key_here"
python main.py
```

> Important: without a valid API key, the Gemini AI feature will not work.

---

## 6. Current Project Status

The project has been reviewed and the main problem was the missing Google Gemini SDK plus the environment key configuration. The import issue has been fixed in the project files, and the Gemini helper is now set to work correctly when a valid API key is provided.

The app is ready from a code perspective, but it still needs a real Gemini key to run the AI functionality successfully.

---

## 7. GitHub Upload Instructions

This folder is not currently a Git repository, so it cannot be uploaded to GitHub from this location without first creating a Git repository and a remote connection.

### If the repository already exists locally

```bash
git init
git add .
git commit -m "Add smart meal planner project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### If you have a repository URL already

Use the URL from your GitHub repo and replace the placeholder above.

### If you do not have a repository yet

1. Open GitHub in your browser.
2. Click New repository.
3. Give it a name such as `smart-meal-planner`.
4. Create the repository.
5. Connect the local project to it using the commands above.

---

## 8. Final Team Statement

This project demonstrates effective teamwork, practical software design, and the integration of modern AI capabilities into a useful desktop application. Each team member contributed to a core part of the system, and together the work resulted in a complete meal-planning tool that is functional, interactive, and relevant to real-world user needs.
